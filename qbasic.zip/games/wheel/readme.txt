Wheel of Fun v0.1a  (Nov 1996)
 Another free game by Daniel Kalna
 I can be reached at: drktex@geocities.com
 Look for my other games coming soon to the internet, all free,
 source code included.  
 

 Read the WHEEL.TXT file for information about this and other games.
